//
//  AppDelegate.h
//  Qyer
//
//  Created by tarena on 16/11/16.
//  Copyright © 2016年 DKD. All rights reserved.
//


#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
  
@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

