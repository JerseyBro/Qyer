//
//  NSString+WX.h
//  TRProject
//
//  Created by “Skip、 on 2016/11/16.
//  Copyright © 2016年 Tedu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (WX)

-(NSURL *)wx_URL;


@end
