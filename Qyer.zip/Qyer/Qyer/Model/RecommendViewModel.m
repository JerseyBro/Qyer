//
//  RecommendViewModel.m
//  Qyer
//
//  Created by “Skip、 on 2016/11/22.
//  Copyright © 2016年 DKD. All rights reserved.
//

#import "RecommendViewModel.h"

@implementation RecommendViewModel

@end
