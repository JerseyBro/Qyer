//
//  CityheadCell.m
//  Qyer
//
//  Created by 😘王艳 on 2016/11/23.
//  Copyright © 2016年 DKD. All rights reserved.
//

#import "CityheadCell.h"

@implementation CityheadCell

//-(NSArray<NSString *> *)picture
//{
//    if (!_picture) {
//        _picture = [NSArray new];
//        [self.icvc reloadData];
//    }
//    return _picture;
//}


-(UILabel *)enname
{
    if (!_enname) {
        _enname = [UILabel new];
        [self.contentView addSubview:_enname];
        
        [_enname mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.equalTo(0);
        }];
      
    }
      return _enname;
}
#pragma mark ----- icvc  数据源  代理
//设置分区
//-(NSInteger)numberOfItemsInCarousel:(iCarousel *)carousel
//{
//    return self.picture.count;
//}
////  每个 carousel 显示什么
//-(UIView *)carousel:(iCarousel *)carousel viewForItemAtIndex:(NSInteger)index reusingView:(UIView *)view
//{
//    if (!view) {
//     view = [UIImageView new];
//    }
//    [((UIImageView*)view) setImageURL:self.picture[index].wx_URL];
//    return view;
//}
////     设置允许循环滚动
//-(CGFloat)carousel:(iCarousel *)carousel valueForOption:(iCarouselOption)option withDefault:(CGFloat)value
//{
//    if (option == iCarouselOptionWrap) {
//        value = YES;
//    }
//    return value;
//}
@end
