//
//  bournzonCell.h
//  Qyer
//
//  Created by 😘王艳 on 2016/11/20.
//  Copyright © 2016年 DKD. All rights reserved.
//

#import <UIKit/UIKit.h>
// 目的地分区
@interface bournzonCell : UITableViewCell
/***
 **   目的地分区名称
 **
 ***/
@property (nonatomic, strong) UILabel * tagname;
@end

