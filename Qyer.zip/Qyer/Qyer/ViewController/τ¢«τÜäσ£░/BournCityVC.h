//
//  BournCityVC.h
//  Qyer
//
//  Created by 😘王艳 on 2016/11/23.
//  Copyright © 2016年 DKD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BournCityVC : UIViewController
@property(nonatomic,assign) NSInteger idField;
@end
