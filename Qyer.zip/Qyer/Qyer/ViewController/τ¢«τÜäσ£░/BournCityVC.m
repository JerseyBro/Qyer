//
//  BournCityVC.h
//  Qyer
//
//  Created by 😘王艳 on 2016/11/23.
//  Copyright © 2016年 DKD. All rights reserved.
//
#import "BournCityVC.h"
#import "CityheadCell.h"
#import "HeaddownCell.h"
//屏幕宽
#define WIDTH  [UIScreen mainScreen].bounds.size.width
#define HEIGHT [UIScreen mainScreen].bounds.size.height
@interface BournCityVC ()<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,iCarouselDelegate,iCarouselDataSource>



@property(nonatomic) CityVSCountryModel* datalist;

@property(nonatomic) NSArray<NSString*> *picture;

@property(nonatomic) UICollectionView *cityView;

@property(nonatomic) UICollectionViewFlowLayout* layou;

@property(nonatomic) iCarousel* icvc;

@property(nonatomic) UIView* HeadView;
@end

@implementation BournCityVC

-(NSInteger)numberOfItemsInCarousel:(iCarousel *)carousel
{
    return self.picture.count;
}
//  每个 carousel 显示什么
-(UIView *)carousel:(iCarousel *)carousel viewForItemAtIndex:(NSInteger)index reusingView:(UIView *)view
{
    if (!view) {
        view = [UIImageView new];
    }
    [((UIImageView*)view) setImageURL:self.picture[index].wx_URL];
    return view;
}
//     设置允许循环滚动
-(CGFloat)carousel:(iCarousel *)carousel valueForOption:(iCarouselOption)option withDefault:(CGFloat)value
{
    if (option == iCarouselOptionWrap) {
        value = YES;
    }
    return value;
}

-(UIView *)HeadView
{
    if (!_HeadView) {
        _HeadView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 100)];
            if (!_icvc) {
                _icvc = [iCarousel new];
                [self.HeadView addSubview:_icvc];
                [_icvc mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.edges.equalTo(0);
                }];
                self.icvc.delegate = self;
                self.icvc.dataSource = self;
                
                _icvc.scrollSpeed = 0;
//            return _icvc;
        }
    }
    return _HeadView;
}



-(UICollectionViewFlowLayout *)layou
{
    if (!_layou) {
        _layou = [[UICollectionViewFlowLayout alloc]init];
    }
    return _layou;
}
-(UICollectionView*)cityView
{
    if (!_cityView) {
        _cityView = [[UICollectionView alloc]initWithFrame:CGRectMake( 0, 0, WIDTH , HEIGHT) collectionViewLayout:self.layou];
        _cityView.delegate = self;
        _cityView.dataSource = self;
        [_cityView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:@"Cell"];
        _cityView.backgroundColor = [UIColor greenColor];
        _cityView.scrollEnabled = YES;
        //注册分区头视图
           [self.cityView registerClass:[UICollectionReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"headerView"];
        [_cityView registerClass:[CityheadCell class] forCellWithReuseIdentifier:@"CityheadCell"];
        
    }
    return _cityView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    // 添加到父类中.并调用其懒加载
    [self.view addSubview:self.cityView];
    //  获取数据
    [NetManager getBournCityVSCountryModelWithidField:self.idField completionHandler:^(CityVSCountryModel *pic, NSError *error) {
        self.datalist = pic;
        self.cityView.delegate = self;
        self.cityView.dataSource = self;
        // 为什么刷新没跑
        [self.cityView reloadData];
    }];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark ----- Collection 代理

-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 2;
}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    if (section == 0) {
        return 1;
    }
    if (section == 1) {
        return 2;
    }
    return 0;
}
-(UICollectionViewCell*)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    
    if (indexPath.section == 0) {
        CityheadCell* cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"CityheadCell" forIndexPath:indexPath];
//        CityheadCell * cell = [[CityheadCell alloc]init];
       self.picture = self.datalist.data.cityPic;
        [cell.contentView addSubview:[self HeadView]];

        cell.enname.text  = self.datalist.data.enname;

        cell.backgroundColor = [UIColor whiteColor];
        return cell;
    }
    UICollectionViewCell* cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"Cell" forIndexPath:indexPath];
    if (indexPath.section  ==  1) {
        if (indexPath.row == 0) {
            cell.backgroundColor = [UIColor redColor];
            return cell;
        }
        if (indexPath.row == 1) {
            cell.backgroundColor = [UIColor blueColor];
            return cell;
        }
    }
    return cell;
}
#pragma mark ----- layou 代理
// 边距
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(0, 0, 0, 0);
}
// 行
-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    return 0;
}
// 列
-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    return 0;
}
// item 大小
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    // CGFloat hight = HEIGHT *
    if (!indexPath.section)
    {
        return CGSizeMake(WIDTH,HEIGHT * 90 / 1135);
    }
    if (indexPath.section == 1)
    {
        if (indexPath.row == 1)
        {
            return CGSizeMake(WIDTH,HEIGHT* 80 / 1135 );
        }
        if (indexPath.row == 0)
        {
            return CGSizeMake(WIDTH, HEIGHT * 166 / 1135);
        }
    }
    return CGSizeMake(0, 0);
}
// 表尾 大小
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout referenceSizeForFooterInSection:(NSInteger)section
{
    CGFloat hight = HEIGHT * 10 / 1135;
    return CGSizeMake(WIDTH, hight);
}
// 表头大小
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section
{
    
    if (section == 0) {
        CGFloat hight = HEIGHT * 467 / 1135;
        return CGSizeMake(WIDTH, hight);
    }
    if (section == 1) {
        CGFloat hight = HEIGHT * 385 / 1135;
        return CGSizeMake(WIDTH, hight);
    }
    return CGSizeMake(0, 0);
}
-(UICollectionReusableView*)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    UICollectionReusableView* headerView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"headerView" forIndexPath:indexPath];
    //UICollectionReusableView* cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"Cell" forIndexPath:indexPath];
    if (indexPath.section == 0) {
        headerView.backgroundColor = [UIColor orangeColor];
        return headerView;
    }
    if (indexPath.section == 1) {
        headerView.backgroundColor = [UIColor purpleColor];
        return headerView;
    }
    headerView.backgroundColor = [UIColor whiteColor];
    return headerView;
}
@end
